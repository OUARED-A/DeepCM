/*---------------------------------------------------------------------------------------------*/
package dw.qmt.perform;
/*---------------------------------------------------------------------------------------------*/
import java.io.*;
import javax.swing.*;
/**************************
* @author Ahc�ne Boukor�a *
***************************/
public class ClassMain {
	
	public static void main(String[] args)throws ClassNotFoundException, InstantiationException, IOException  {

        try
		{
			 UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");

		}
		catch(Exception e)
		{

		}
        
     
        InterfaceAuth interfaceAuth=new InterfaceAuth();
        
        
        
      

    }
}
